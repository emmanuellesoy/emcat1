<a href="<?=base_url(); ?>index.php/ventas/nueva_venta"><label>NUEVA VENTA</label></a>
<a href="<?php echo base_url(); ?>index.php/ventas/ver_fechas_ventas"><label>REPORTE DE VENTAS</label></a>