<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<label>ELIJA LAS FECHAS DE SUS REPORTES:</label>
<input type="date" autofocus/>
<input type="date" />
<form>
    <input type="submit" value="BUSCAR"/>
</form> 