<a href="<?=base_url(); ?>index.php/principal/index/nuevo_cliente"><label>AGREGAR CLIENTE</label></a>
<br />
<a href="<?=base_url(); ?>index.php/principal/index/buscar_cliente"><label>BUSCAR CLIENTE</label></a>