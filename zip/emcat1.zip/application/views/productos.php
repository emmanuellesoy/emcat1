<a href="<?=base_url(); ?>index.php/principal/index/nuevo_producto"><label> AGREGAR PRODUCTO</label></a>
<a href="<?=base_url(); ?>index.php/principal/index/editar_producto"><label>EDITAR PRODUCTOS</label></a>
<a href="<?=base_url(); ?>index.php/productos/listar_productos"><label>LISTA DE PRODUCTOS</label></a>