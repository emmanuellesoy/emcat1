    <meta charset="utf-8">
    <title><?=$title; ?></title>
    <link rel="stylesheet" type="text/css" href="<?=($title == 'Detalle Venta' || $title == 'Buscar Producto') ? base_url().'statics/css/detalle_venta.css': base_url().'statics/css/index.css'?>" />
    <script type="text/javascript" src="<?=base_url(); ?>statics/js/jquery-1.7.2.min.js"></script>
    <script type="text/javascript" src="<?=base_url(); ?>statics/js/clientes.js"></script>
    <script type="text/javascript" src="<?=base_url(); ?>statics/js/venta.js"></script>
    <script type="text/javascript">var base = "<?=base_url(); ?>";</script>