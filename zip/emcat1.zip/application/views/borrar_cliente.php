<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<link rel="stylesheet" type="text/css" 
      href="<?php echo base_url(); ?>statics/css/index.css" />
<secton id="borrar_cliente">
    <form id="fborrar_clietne">
        <table id="tborrar_cliente">
            <tr>
                <td>
                    <label>NOMBRE O NUMERO DEL CLIENTE:</label>
                    <input type="text" id="tbuscar_cliente" autofocus />
                </td>
            </tr>
            <tr>
                <td>
                    <input type="submit" id="bbuscar_cliente" value="BUSCAR" />
                </td>
            </tr>    
        </table><!-- Termina tabla[tborrar_cliete] -->
    </form><!-- Termina formulario[fborrar_cliente] -->
</secton><!-- Termina sección[borrar_cliete] -->    