<ul>
    <li><a href="<?=base_url(); ?>index.php/principal/index/ventas"><label>VENTAS</label></a></li>
    <li><a href="<?=base_url(); ?>index.php/principal/index/clientes"><label>CLIENTES</label></a></li>
    <li><a href="<?=base_url(); ?>index.php/principal/index/productos"><label>PRODUCTOS</label></a></li>
</ul>